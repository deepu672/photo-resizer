package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.PreloadedClassicData
import com.example.data.SavedScriptDao
import com.example.data.SavedScriptEntity
import com.example.model.AudioDramaScript
import com.example.model.GlossaryItem
import com.example.model.LiteraryWork
import com.example.service.AudioPerformanceEngine
import com.example.service.GeminiScriptGenerator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

class AudioDramaViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val savedScriptDao: SavedScriptDao = db.savedScriptDao()

    val audioEngine = AudioPerformanceEngine(application)

    val classicWorks = PreloadedClassicData.CLASSIC_WORKS

    val savedScripts = savedScriptDao.getAllSavedScripts()

    private val _selectedWork = MutableStateFlow<LiteraryWork?>(PreloadedClassicData.CLASSIC_WORKS.first())
    val selectedWork: StateFlow<LiteraryWork?> = _selectedWork.asStateFlow()

    private val _currentScript = MutableStateFlow<AudioDramaScript>(PreloadedClassicData.GODAN_EPISODE_1)
    val currentScript: StateFlow<AudioDramaScript> = _currentScript.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _selectedGlossary = MutableStateFlow<GlossaryItem?>(null)
    val selectedGlossary: StateFlow<GlossaryItem?> = _selectedGlossary.asStateFlow()

    private val _showExportDialog = MutableStateFlow(false)
    val showExportDialog: StateFlow<Boolean> = _showExportDialog.asStateFlow()

    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true }

    init {
        audioEngine.loadScript(PreloadedClassicData.GODAN_EPISODE_1)
    }

    fun selectWork(work: LiteraryWork) {
        _selectedWork.value = work
        val script = when (work.id) {
            "godan" -> PreloadedClassicData.GODAN_EPISODE_1
            "idgah" -> PreloadedClassicData.IDGAH_EPISODE_1
            else -> PreloadedClassicData.GODAN_EPISODE_1
        }
        _currentScript.value = script
        audioEngine.loadScript(script)
    }

    fun loadScriptDirectly(script: AudioDramaScript) {
        _currentScript.value = script
        audioEngine.loadScript(script)
    }

    fun loadScriptFromEntity(entity: SavedScriptEntity) {
        try {
            val script = json.decodeFromString<AudioDramaScript>(entity.scriptJson)
            _currentScript.value = script
            audioEngine.loadScript(script)
        } catch (e: Exception) {
            e.printStackTrace()
            _errorMessage.value = "Failed to load saved script format: ${e.message}"
        }
    }

    fun generateCustomScript(
        rawText: String,
        bookTitle: String,
        authorName: String
    ) {
        if (rawText.isBlank()) {
            _errorMessage.value = "Please enter story text to process into an Audio Drama script."
            return
        }

        viewModelScope.launch {
            _isGenerating.value = true
            _errorMessage.value = null

            val result = GeminiScriptGenerator.generateAudioDramaScript(
                rawStoryText = rawText,
                bookTitle = bookTitle,
                authorName = authorName
            )

            _isGenerating.value = false

            result.onSuccess { script ->
                _currentScript.value = script
                audioEngine.loadScript(script)

                // Save to Room DB automatically
                try {
                    val scriptJson = json.encodeToString(AudioDramaScript.serializer(), script)
                    savedScriptDao.insertScript(
                        SavedScriptEntity(
                            title = if (bookTitle.isNotBlank()) bookTitle else script.metadata.title,
                            authorName = if (authorName.isNotBlank()) authorName else "Custom Story",
                            rawStoryText = rawText,
                            scriptJson = scriptJson
                        )
                    )
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }.onFailure { err ->
                _errorMessage.value = err.message ?: "Failed to generate Audio Drama script."
            }
        }
    }

    fun showGlossary(item: GlossaryItem?) {
        _selectedGlossary.value = item
    }

    fun toggleExportDialog(show: Boolean) {
        _showExportDialog.value = show
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun deleteSavedScript(id: Long) {
        viewModelScope.launch {
            savedScriptDao.deleteScriptById(id)
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.release()
    }
}
