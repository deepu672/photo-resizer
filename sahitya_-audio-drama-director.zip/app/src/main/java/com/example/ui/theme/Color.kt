package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GarnetPrimary = Color(0xFF4A121A)
val GarnetSecondary = Color(0xFF8C2635)
val GoldAccent = Color(0xFFD49A3A)
val GoldLight = Color(0xFFF5D080)
val ParchmentBg = Color(0xFFFFF9F0)
val ParchmentCard = Color(0xFFFFF3E2)
val DarkBackground = Color(0xFF180D10)
val DarkSurface = Color(0xFF2B161B)
val SitarBronze = Color(0xFF8B5E34)
val DeepText = Color(0xFF231A1C)
val SoftGoldContainer = Color(0xFFFBE6C2)
