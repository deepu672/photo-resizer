package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GoldAccent,
    onPrimary = GarnetPrimary,
    primaryContainer = GarnetPrimary,
    onPrimaryContainer = GoldLight,
    secondary = GoldLight,
    onSecondary = DarkBackground,
    tertiary = SitarBronze,
    background = DarkBackground,
    onBackground = ParchmentBg,
    surface = DarkSurface,
    onSurface = ParchmentBg,
    surfaceVariant = Color(0xFF3B1E25),
    onSurfaceVariant = GoldLight
)

private val LightColorScheme = lightColorScheme(
    primary = GarnetPrimary,
    onPrimary = Color.White,
    primaryContainer = SoftGoldContainer,
    onPrimaryContainer = GarnetPrimary,
    secondary = GarnetSecondary,
    onSecondary = Color.White,
    tertiary = GoldAccent,
    background = ParchmentBg,
    onBackground = DeepText,
    surface = ParchmentCard,
    onSurface = DeepText,
    surfaceVariant = Color(0xFFF7E8D3),
    onSurfaceVariant = GarnetPrimary
)

@Composable
fun KathaVaniTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

