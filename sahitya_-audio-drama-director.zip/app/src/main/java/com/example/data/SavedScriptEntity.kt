package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_scripts")
data class SavedScriptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val authorName: String,
    val rawStoryText: String,
    val scriptJson: String,
    val createdAt: Long = System.currentTimeMillis()
)
