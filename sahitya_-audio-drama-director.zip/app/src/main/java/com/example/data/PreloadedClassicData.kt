package com.example.data

import com.example.R
import com.example.model.AudioDramaScript
import com.example.model.EpisodeMetadata
import com.example.model.GlossaryItem
import com.example.model.LiteraryWork
import com.example.model.ScriptLine
import com.example.model.VoiceMapping

object PreloadedClassicData {

    val CLASSIC_WORKS = listOf(
        LiteraryWork(
            id = "godan",
            title = "Godan",
            hindiTitle = "गौदान",
            author = "Munshi Premchand (मुंशी प्रेमचंद)",
            historicalContext = "1936 Indian Rural Realism Classic",
            description = "The epic saga of Hori, Dhaniya, and the unyielding struggle of the Indian peasant for dignity, debt survival, and the sacred dream of a cow.",
            genre = "Rural Epic Drama",
            episodesCount = 12,
            coverRes = R.drawable.godan_cover_1784804799013
        ),
        LiteraryWork(
            id = "idgah",
            title = "Idgah",
            hindiTitle = "ईदगाह",
            author = "Munshi Premchand (मुंशी प्रेमचंद)",
            historicalContext = "1933 Masterpiece of Child Psychology & Selfless Love",
            description = "The touching story of 4-year-old orphan Hamid who visits the Eid fair with three paise and buys iron tongs (chimta) for his grandmother so she doesn't burn her hands.",
            genre = "Emotional Drama",
            episodesCount = 3,
            coverRes = R.drawable.idgah_cover_1784804811519
        ),
        LiteraryWork(
            id = "kamayani",
            title = "Kamayani",
            hindiTitle = "कामायनी",
            author = "Jaishankar Prasad (जयशंकर प्रसाद)",
            historicalContext = "1936 Chhayavadi Epic Poem of Consciousness & Creation",
            description = "After the great cosmic deluge, Manu sits desolate atop the Himalayas until Shraddha brings hope, love, and spiritual rebirth to humanity.",
            genre = "Philosophical Epic",
            episodesCount = 10,
            coverRes = R.drawable.kathavani_banner_1784804788187
        ),
        LiteraryWork(
            id = "kabuliwala",
            title = "Kabuliwala",
            hindiTitle = "काबूलीवाला",
            author = "Rabindranath Tagore (रवींद्रनाथ टैगोर)",
            historicalContext = "1892 Heart-touching Tale of Universal Fatherhood",
            description = "The deep bond between Mini, a talkative Kolkata girl, and Rahmat, an Afghan dry-fruit seller who misses his daughter in Kabul.",
            genre = "Human Drama",
            episodesCount = 4,
            coverRes = R.drawable.kathavani_banner_1784804788187
        )
    )

    val GODAN_EPISODE_1 = AudioDramaScript(
        id = "godan_ep1",
        workId = "godan",
        metadata = EpisodeMetadata(
            episodeNumber = 1,
            title = "Episode 1: होरी का सपना और पछाईं गाय (Hori's Dream)",
            bookAuthorContext = "1936 में प्रकाशित मुंशी प्रेमचंद का कालजयी उपन्यास 'गौदान' भारतीय किसान की मर्यादा और पीड़ा का महाकाव्य है। बेलारी गाँव का किसान होरी एक पछाईं गाय अपने आँगन में बाँधने का स्वप्न देखता है...",
            sceneSetting = "बेलारी गाँव, जेठ की दोपहरी। धूल भरी कच्ची सड़क और होरी का बाँस का छप्पर।",
            emotionalTone = "Melancholic, Rural, Hopeful yet Tense"
        ),
        characterVoices = listOf(
            VoiceMapping(
                characterId = "narrator",
                name = "Narrator",
                hindiName = "सूत्रधार",
                voiceProfile = "Deep, warm, authoritative, slow-paced classic Urdu/Hindi diction",
                ageGroup = "Elderly Master",
                pitch = 0.9f,
                speechRate = 0.88f,
                defaultEmotion = "Authoritative & Nostalgic"
            ),
            VoiceMapping(
                characterId = "hori",
                name = "Hori",
                hindiName = "होरी",
                voiceProfile = "Aged rural voice, weary, respectful, rasp in voice",
                ageGroup = "50s Rural Peasant",
                pitch = 0.85f,
                speechRate = 0.92f,
                defaultEmotion = "Weary & Hopeful"
            ),
            VoiceMapping(
                characterId = "dhaniya",
                name = "Dhaniya",
                hindiName = "धनिया",
                voiceProfile = "Sharp, highly emotional, fierce caring wife",
                ageGroup = "45s Rural Woman",
                pitch = 1.15f,
                speechRate = 1.05f,
                defaultEmotion = "Fierce & Caring"
            ),
            VoiceMapping(
                characterId = "gobar",
                name = "Gobar",
                hindiName = "गोबर",
                voiceProfile = "Young rebellious teenager, straightforward",
                ageGroup = "18s Youth",
                pitch = 1.1f,
                speechRate = 1.0f,
                defaultEmotion = "Impatient"
            ),
            VoiceMapping(
                characterId = "rai_saheb",
                name = "Rai Saheb",
                hindiName = "राय साहब",
                voiceProfile = "Dignified, refined aristocratic Zemindar tone",
                ageGroup = "40s Aristocrat",
                pitch = 0.95f,
                speechRate = 0.95f,
                defaultEmotion = "Patronizing & Refined"
            )
        ),
        dialogueLines = listOf(
            ScriptLine(
                id = 1,
                speakerId = "narrator",
                speakerName = "सूत्रधार (Narrator)",
                emotionCue = "Nostalgic, Deep",
                breathCue = "Calm breath",
                speedTag = "0.9x",
                text = "जेठ की झुलसा देने वाली दोपहरी। अवध के बेलारी गाँव की कच्ची पगडंडी पर धूल के बवंडर उठ रहे थे। होरी महतो ने सिर पर रखा गंडासा संभाला और खटोले पर बैठी धनिया को देखा...",
                bgmCue = "[BGM: Soft Melancholic Sarangi & Sitar Drone]",
                sfxCue = "[SFX: Bullock cart wooden wheels creaking, distant crows calling in village heat]",
                timestampMs = 0L
            ),
            ScriptLine(
                id = 2,
                speakerId = "hori",
                speakerName = "होरी (Hori)",
                emotionCue = "Weary, Respectful",
                breathCue = "Heavy sigh",
                speedTag = "0.9x",
                text = "धनिया! सुनती हो... मैं जरा राय साहब के बँगले तक हो आऊँ। सुभांव का समय है, नजरानी न दी तो मरियाद कैसे बचेगी?",
                bgmCue = null,
                sfxCue = "[SFX: Rustle of coarse cotton dhoti and wooden slippers]",
                timestampMs = 12000L
            ),
            ScriptLine(
                id = 3,
                speakerId = "dhaniya",
                speakerName = "धनिया (Dhaniya)",
                emotionCue = "Fierce, Anxious",
                breathCue = "Sharp intake of air",
                speedTag = "1.05x",
                text = "रहो भी! हर पखवाड़े दौड़ते हो जमींदार के चौखट पर! घर में न भूसा है न अनाज का दाना, पर रईसी और मर्ज़ाद का नशा नहीं उतरता!",
                bgmCue = "[BGM: Sitar Tension Note]",
                sfxCue = "[SFX: Clinking of brass pitcher on stone threshold]",
                timestampMs = 22000L
            ),
            ScriptLine(
                id = 4,
                speakerId = "hori",
                speakerName = "होरी (Hori)",
                emotionCue = "Gentle, Longing",
                breathCue = "Soft smile in voice",
                speedTag = "0.92x",
                text = "अरे पगली, जमींदार की दया न रहे तो खेत कौन बोने देगा? और फिर... रास्ते में भोला अहीर का घर पड़ता है। उसकी पछाईं गाय देख कर छाती ठंडी हो जाती है। काश! हमारे आँगन में भी एक गाय कढ़ी होती...",
                bgmCue = "[BGM: Flute Melancholic Melody]",
                sfxCue = "[SFX: Distant cow bell tinkling softly]",
                timestampMs = 34000L
            ),
            ScriptLine(
                id = 5,
                speakerId = "gobar",
                speakerName = "गोबर (Gobar)",
                emotionCue = "Rebellious, Young",
                breathCue = "Snort",
                speedTag = "1.0x",
                text = "बापा! गाय तो भोला काका मुफ़्त में न देंगे! साठ रुपये की दुधारू गाय है। हमारे पास तो महाजन की सूद चुकाने के पैसे नहीं हैं!",
                bgmCue = null,
                sfxCue = "[SFX: Chopping firewood with axe rhythmically]",
                timestampMs = 48000L
            ),
            ScriptLine(
                id = 6,
                speakerId = "narrator",
                speakerName = "सूत्रधार (Narrator)",
                emotionCue = "Poignant, Authoritative",
                breathCue = "Slow breath",
                speedTag = "0.88x",
                text = "होरी चुप हो गया। एक गाय का सपना उसके लिए केवल दूध या लक्ष्मी का प्रतीक नहीं था... वह किसान की जीवन-भर की साधना, उसकी मर्यादा का मुकुट थी।",
                bgmCue = "[BGM: Full Sarangi Orchestra Crescendo]",
                sfxCue = "[SFX: Gentle breeze blowing through dry sugarcane field]",
                timestampMs = 58000L
            )
        ),
        glossary = listOf(
            GlossaryItem(
                word = "मरियाद / मर्ज़ाद (Marzad)",
                meaning = "सामाजिक प्रतिष्ठा, स्वाभिमान और किसान की मर्यादा।",
                contextSentence = "नजरानी न दी तो मरियाद कैसे बचेगी?"
            ),
            GlossaryItem(
                word = "पछाईं गाय (Pachhain Cow)",
                meaning = "पश्चिमी भारत की ऊँची नस्ल की अधिक दूध देने वाली श्रेष्ठ गाय।",
                contextSentence = "उसकी पछाईं गाय देख कर छाती ठंडी हो जाती है।"
            ),
            GlossaryItem(
                word = "महाजन (Mahajan)",
                meaning = "गाँव का साहूकार जो किसानों को ब्याज (सूद) पर कर्ज देता है।",
                contextSentence = "हमारे पास तो महाजन की सूद चुकाने के पैसे नहीं हैं!"
            ),
            GlossaryItem(
                word = "जेठ (Jeth)",
                meaning = "हिन्दी पंचांग का ज्येष्ठ मास (भीषण गर्मी का मई-जून महीना)।",
                contextSentence = "जेठ की झुलसा देने वाली दोपहरी।"
            )
        )
    )

    val IDGAH_EPISODE_1 = AudioDramaScript(
        id = "idgah_ep1",
        workId = "idgah",
        metadata = EpisodeMetadata(
            episodeNumber = 1,
            title = "Episode 1: हामिद का चिमटा और दादी की ममता (Hamid's Chimta)",
            bookAuthorContext = "मुंशी प्रेमचंद की कालजयी कहानी 'ईदगाह' (1933) बाल-मनोविज्ञान, त्याग और एक 4 साल के बच्चे के निश्छल प्रेम का अमर आख्यान है...",
            sceneSetting = "ईद का पावन दिन। गाँव में ईदगाह जाने की हलचल और बूढ़ी अमीना की टूटी कोठरी।",
            emotionalTone = "Festive yet Heart-touching, Innocent, Emotional"
        ),
        characterVoices = listOf(
            VoiceMapping(
                characterId = "narrator",
                name = "Narrator",
                hindiName = "सूत्रधार",
                voiceProfile = "Warm, poetic, narrative classic tone",
                ageGroup = "Master Storyteller",
                pitch = 0.9f,
                speechRate = 0.9f
            ),
            VoiceMapping(
                characterId = "hamid",
                name = "Hamid",
                hindiName = "हामिद",
                voiceProfile = "Innocent 4-year old boy, bright and cheerful tone",
                ageGroup = "Child",
                pitch = 1.3f,
                speechRate = 1.05f
            ),
            VoiceMapping(
                characterId = "ameena",
                name = "Ameena",
                hindiName = "दादी अमीना",
                voiceProfile = "Frail elderly grandmother, crackling tearful voice",
                ageGroup = "Elderly 70s",
                pitch = 0.8f,
                speechRate = 0.85f
            )
        ),
        dialogueLines = listOf(
            ScriptLine(
                id = 1,
                speakerId = "narrator",
                speakerName = "सूत्रधार (Narrator)",
                emotionCue = "Joyful, Festive",
                breathCue = "Warm breath",
                speedTag = "0.9x",
                text = "रमजान के पूरे तीस रोजों के बाद आज ईद आई है। कितना मनोहर, कितना सुहावना प्रभात है! वृक्षों पर कुछ अजीब हरियाली है, खेतों में कुछ अजीब रौनक है।",
                bgmCue = "[BGM: Joyful Shehnai & Festival Tabla Rhythm]",
                sfxCue = "[SFX: Birds chirping on banyan tree, children laughing in distance]",
                timestampMs = 0L
            ),
            ScriptLine(
                id = 2,
                speakerId = "hamid",
                speakerName = "हामिद (Hamid)",
                emotionCue = "Excited, Loving",
                breathCue = "Gasp of surprise",
                speedTag = "1.05x",
                text = "दादी! तुम डरना नहीं, मैं सब से पहले ईदगाह जाऊँगा और सब से पहले लौट आऊँगा! मेरे पास तीन पैसे हैं ना!",
                bgmCue = null,
                sfxCue = "[SFX: Clinking of three small copper coins in cloth pocket]",
                timestampMs = 15000L
            ),
            ScriptLine(
                id = 3,
                speakerId = "ameena",
                speakerName = "दादी अमीना (Ameena)",
                emotionCue = "Tearful, Protective",
                breathCue = "Trembling voice",
                speedTag = "0.85x",
                text = "हामिद रे... नंगे पैर जाएगा? पाँव में छाले पड़ जाएँगे! न जूते हैं ना टोपी। भगवान! तू ही मेरे बच्चे का रखवाला है...",
                bgmCue = "[BGM: Soft Emotion Sarangi]",
                sfxCue = "[SFX: Heavy tear falling on worn cotton blanket]",
                timestampMs = 26000L
            ),
            ScriptLine(
                id = 4,
                speakerId = "narrator",
                speakerName = "सूत्रधार (Narrator)",
                emotionCue = "Poignant",
                breathCue = "Slow",
                speedTag = "0.9x",
                text = "मेले में जहाँ बच्चों ने खिलौने और मिठाई खरीदी, वहीं हामिद लोहे की दुकान पर रुक गया। उसे याद आया कि रोटियाँ उतारते वक्त दादी की उंगलियाँ जल जाती हैं...",
                bgmCue = "[BGM: Deep Emotional Sitar Theme]",
                sfxCue = "[SFX: Clinking iron tongs on blacksmith counter]",
                timestampMs = 38000L
            )
        ),
        glossary = listOf(
            GlossaryItem(
                word = "ईदगाह (Idgah)",
                meaning = "ईद की पावन नमाज़ अदा करने का नगर से बाहर स्थित बड़ा खुला स्थल।",
                contextSentence = "मैं सब से पहले ईदगाह जाऊँगा।"
            ),
            GlossaryItem(
                word = "चिमटा (Chimta)",
                meaning = "तवे से रोटी सेकने या पलटने का लोहे का यन्त्र।",
                contextSentence = "हामिद ने तीन पैसे में चिमटा खरीदा।"
            ),
            GlossaryItem(
                word = "समीयाना / टोपी (Samiyana)",
                meaning = "पारंपरिक वस्त्र व मस्तक ढकने का आभूषण।",
                contextSentence = "न जूते हैं ना टोपी।"
            )
        )
    )
}
