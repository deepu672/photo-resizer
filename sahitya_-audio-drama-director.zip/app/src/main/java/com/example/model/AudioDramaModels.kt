package com.example.model

import androidx.annotation.DrawableRes
import kotlinx.serialization.Serializable

data class LiteraryWork(
    val id: String,
    val title: String,
    val hindiTitle: String,
    val author: String,
    val historicalContext: String,
    val description: String,
    val genre: String,
    val episodesCount: Int,
    @DrawableRes val coverRes: Int? = null
)

@Serializable
data class VoiceMapping(
    val characterId: String,
    val name: String,
    val hindiName: String,
    val voiceProfile: String,
    val ageGroup: String,
    val pitch: Float = 1.0f,
    val speechRate: Float = 1.0f,
    val defaultEmotion: String = "Neutral"
)

@Serializable
data class ScriptLine(
    val id: Int,
    val speakerId: String,
    val speakerName: String,
    val emotionCue: String, // e.g. "Despair", "Warm", "Angry", "Whispering"
    val breathCue: String = "", // e.g. "Heavy breath", "Sighing"
    val speedTag: String = "1.0x",
    val text: String,
    val bgmCue: String? = null, // e.g. "[BGM: Soft Melancholic Sarangi]"
    val sfxCue: String? = null, // e.g. "[SFX: Bullock cart wheels on unpaved road]"
    val timestampMs: Long = 0L
)

@Serializable
data class GlossaryItem(
    val word: String,
    val meaning: String,
    val contextSentence: String
)

@Serializable
data class EpisodeMetadata(
    val episodeNumber: Int,
    val title: String,
    val bookAuthorContext: String,
    val sceneSetting: String,
    val emotionalTone: String
)

@Serializable
data class AudioDramaScript(
    val id: String,
    val workId: String? = null,
    val metadata: EpisodeMetadata,
    val characterVoices: List<VoiceMapping>,
    val dialogueLines: List<ScriptLine>,
    val glossary: List<GlossaryItem>
)
