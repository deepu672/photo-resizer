package com.example.service

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.model.AudioDramaScript
import com.example.model.ScriptLine
import com.example.model.VoiceMapping
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

class AudioPerformanceEngine(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isTtsReady = false

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var currentScript: AudioDramaScript? = null

    private val _currentLineIndex = MutableStateFlow(0)
    val currentLineIndex: StateFlow<Int> = _currentLineIndex.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _activeBgm = MutableStateFlow<String?>(null)
    val activeBgm: StateFlow<String?> = _activeBgm.asStateFlow()

    private val _activeSfx = MutableStateFlow<String?>(null)
    val activeSfx: StateFlow<String?> = _activeSfx.asStateFlow()

    private val _spokenLine = MutableStateFlow("")
    val spokenLine: StateFlow<String> = _spokenLine.asStateFlow()

    private var playJob: Job? = null
    private var bgmToneTrack: AudioTrack? = null
    private var isBgmPlaying = false

    init {
        setupTtsUtteranceListener()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to default locale if Hindi language pack is missing
                tts?.setLanguage(Locale.getDefault())
            }
            isTtsReady = true
        } else {
            Log.e("AudioPerformanceEngine", "TTS initialization failed!")
        }
    }

    private fun setupTtsUtteranceListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _isPlaying.value = true
            }

            override fun onDone(utteranceId: String?) {
                // When line completes, trigger next line if auto playing
                scope.launch {
                    if (_isPlaying.value) {
                        delay(600)
                        val nextIndex = _currentLineIndex.value + 1
                        val totalLines = currentScript?.dialogueLines?.size ?: 0
                        if (nextIndex < totalLines) {
                            playLine(nextIndex)
                        } else {
                            _isPlaying.value = false
                            stopBgmSound()
                        }
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _isPlaying.value = false
            }
        })
    }

    fun loadScript(script: AudioDramaScript) {
        currentScript = script
        _currentLineIndex.value = 0
        _spokenLine.value = script.dialogueLines.firstOrNull()?.text ?: ""
        _activeBgm.value = script.dialogueLines.firstOrNull()?.bgmCue
        _activeSfx.value = script.dialogueLines.firstOrNull()?.sfxCue
    }

    fun play() {
        val script = currentScript ?: return
        if (script.dialogueLines.isEmpty()) return
        _isPlaying.value = true
        startBgmSimulation(script.dialogueLines.getOrNull(_currentLineIndex.value)?.bgmCue)
        playLine(_currentLineIndex.value)
    }

    fun pause() {
        _isPlaying.value = false
        tts?.stop()
        stopBgmSound()
    }

    fun seekToLine(index: Int) {
        val script = currentScript ?: return
        if (index in script.dialogueLines.indices) {
            _currentLineIndex.value = index
            if (_isPlaying.value) {
                playLine(index)
            } else {
                val line = script.dialogueLines[index]
                _spokenLine.value = line.text
                _activeBgm.value = line.bgmCue ?: _activeBgm.value
                _activeSfx.value = line.sfxCue
            }
        }
    }

    fun setSpeed(speed: Float) {
        _playbackSpeed.value = speed
        if (_isPlaying.value) {
            playLine(_currentLineIndex.value)
        }
    }

    private fun playLine(index: Int) {
        val script = currentScript ?: return
        val lines = script.dialogueLines
        if (index !in lines.indices) {
            _isPlaying.value = false
            return
        }

        _currentLineIndex.value = index
        val line = lines[index]
        _spokenLine.value = line.text

        if (line.bgmCue != null) {
            _activeBgm.value = line.bgmCue
            startBgmSimulation(line.bgmCue)
        }
        if (line.sfxCue != null) {
            _activeSfx.value = line.sfxCue
        }

        val voiceMapping = findVoiceMapping(script, line.speakerId, line.speakerName)

        if (isTtsReady && tts != null) {
            val basePitch = voiceMapping?.pitch ?: 1.0f
            val baseRate = (voiceMapping?.speechRate ?: 1.0f) * _playbackSpeed.value

            // Emotion pitch tweaks
            val finalPitch = when {
                line.emotionCue.contains("Innocent", ignoreCase = true) -> basePitch * 1.15f
                line.emotionCue.contains("Angry", ignoreCase = true) -> basePitch * 1.1f
                line.emotionCue.contains("Despair", ignoreCase = true) -> basePitch * 0.85f
                line.emotionCue.contains("Deep", ignoreCase = true) -> basePitch * 0.88f
                else -> basePitch
            }

            tts?.setPitch(finalPitch)
            tts?.setSpeechRate(baseRate)

            val params = HashMap<String, String>()
            params[TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID] = "line_$index"
            tts?.speak(line.text, TextToSpeech.QUEUE_FLUSH, params)
        } else {
            // Fallback timer simulation if TTS is initializing or offline
            playJob?.cancel()
            playJob = scope.launch {
                val charDurationMs = (line.text.length * 90 / _playbackSpeed.value).toLong().coerceAtLeast(2500L)
                delay(charDurationMs)
                if (_isPlaying.value) {
                    val nextIndex = index + 1
                    if (nextIndex < lines.size) {
                        playLine(nextIndex)
                    } else {
                        _isPlaying.value = false
                    }
                }
            }
        }
    }

    private fun findVoiceMapping(script: AudioDramaScript, speakerId: String, speakerName: String): VoiceMapping? {
        return script.characterVoices.firstOrNull {
            it.characterId.equals(speakerId, ignoreCase = true) ||
                    speakerName.contains(it.name, ignoreCase = true) ||
                    speakerName.contains(it.hindiName, ignoreCase = true)
        }
    }

    private fun startBgmSimulation(bgmTag: String?) {
        if (bgmTag == null) return
        if (isBgmPlaying) return

        try {
            scope.launch(Dispatchers.IO) {
                isBgmPlaying = true
                val sampleRate = 22050
                val numSamples = sampleRate * 2
                val sample = DoubleArray(numSamples)
                val buffer = ShortArray(numSamples)

                // Generate warm Indian ambient sitar/sarangi drone chord (220Hz A, 330Hz E)
                val freq1 = 220.0
                val freq2 = 330.0
                for (i in 0 until numSamples) {
                    val t = i.toDouble() / sampleRate
                    val wave = 0.08 * Math.sin(2 * Math.PI * freq1 * t) + 0.05 * Math.sin(2 * Math.PI * freq2 * t)
                    sample[i] = wave
                    buffer[i] = (sample[i] * 32767).toInt().toShort()
                }

                bgmToneTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                bgmToneTrack?.write(buffer, 0, buffer.size)
                bgmToneTrack?.setLoopPoints(0, numSamples, -1)
                bgmToneTrack?.play()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopBgmSound() {
        try {
            isBgmPlaying = false
            bgmToneTrack?.stop()
            bgmToneTrack?.release()
            bgmToneTrack = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        stopBgmSound()
    }
}
