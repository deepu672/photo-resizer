package com.example.service

import com.example.BuildConfig
import com.example.model.AudioDramaScript
import com.example.model.EpisodeMetadata
import com.example.model.GlossaryItem
import com.example.model.ScriptLine
import com.example.model.VoiceMapping
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

object GeminiScriptGenerator {

    private const val GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

    private val jsonParser = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generateAudioDramaScript(
        rawStoryText: String,
        bookTitle: String = "",
        authorName: String = ""
    ): Result<AudioDramaScript> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                Exception("Gemini API key is missing. Please configure GEMINI_API_KEY in Secrets or .env file.")
            )
        }

        val prompt = """
            You are the Master Audio Drama Director and Scriptwriter for a premium Literary Audio App (built for authentic, classic Indian literature like Munshi Premchand, Jaishankar Prasad, Rabindranath Tagore, etc.).
            
            YOUR TASK: Convert the following raw story text into a production-ready, highly realistic Pocket FM-style Audio Drama script in Hindi/Urdu.
            
            STRICT RULES:
            1. 100% AUTHENTICITY: Maintain the purity and elegance of the original text. No clickbait or fabricated storylines.
            2. FULL EPISODIC STRUCTURE: Structure as a compelling 10-15 minute audio episode script.
            3. IMMERSIVE AUDIO PLAY: Design it as an audio play with multi-character voices, ambient soundscapes ([SFX: ...]), and emotional music triggers ([BGM: ...]).
            4. GLOSSARY: Extract 3-5 difficult Hindi/Urdu literary words from the text and provide simple meanings.
            
            STORY TEXT / INPUT:
            Book Title: $bookTitle
            Author: $authorName
            Content:
            $rawStoryText
            
            Output MUST be valid JSON matching this schema:
            {
              "metadata": {
                "episodeNumber": 1,
                "title": "Episode 1: Title in Hindi",
                "bookAuthorContext": "30-second narrator introduction providing book/author context and historical setting",
                "sceneSetting": "Description of scene setting and environment in Hindi",
                "emotionalTone": "e.g., Melancholic, Tense, Patriotic, Rural, Emotional"
              },
              "characterVoices": [
                {
                  "characterId": "narrator",
                  "name": "Narrator",
                  "hindiName": "सूत्रधार",
                  "voiceProfile": "Deep, warm, authoritative, slow-paced classic Hindi/Urdu diction",
                  "ageGroup": "Elderly Master",
                  "pitch": 0.9,
                  "speechRate": 0.88,
                  "defaultEmotion": "Authoritative"
                },
                {
                  "characterId": "character_1",
                  "name": "Character Name",
                  "hindiName": "पात्र का नाम",
                  "voiceProfile": "Vocal description e.g. Old rural voice, weary, respectful",
                  "ageGroup": "Middle-Aged / Youth / Elderly",
                  "pitch": 1.0,
                  "speechRate": 1.0,
                  "defaultEmotion": "Emotional"
                }
              ],
              "dialogueLines": [
                {
                  "id": 1,
                  "speakerId": "narrator",
                  "speakerName": "सूत्रधार (Narrator)",
                  "emotionCue": "Nostalgic, Warm",
                  "breathCue": "Calm breath",
                  "speedTag": "0.9x",
                  "text": "Dialogue or narration text in authentic Hindi...",
                  "bgmCue": "[BGM: Soft Melancholic Sarangi / Sitar]",
                  "sfxCue": "[SFX: Bullock cart wheels, distant birds]",
                  "timestampMs": 0
                }
              ],
              "glossary": [
                {
                  "word": "Difficult Hindi Word",
                  "meaning": "Simple Hindi/English meaning",
                  "contextSentence": "Example sentence or context from text"
                }
              ]
            }
        """.trimIndent()

        val jsonRequest = """
            {
              "contents": [
                {
                  "parts": [
                    { "text": ${escapeJson(prompt)} }
                  ]
                }
              ],
              "generationConfig": {
                "responseMimeType": "application/json",
                "temperature": 0.3
              }
            }
        """.trimIndent()

        try {
            val request = Request.Builder()
                .url("$GEMINI_URL?key=$apiKey")
                .post(jsonRequest.toRequestBody("application/json".toMediaType()))
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errBody = response.body?.string() ?: ""
                return@withContext Result.failure(Exception("Gemini API Error: Code ${response.code} - $errBody"))
            }

            val responseBody = response.body?.string() ?: ""
            val jsonElement = jsonParser.parseToJsonElement(responseBody)
            val generatedText = jsonElement.asJsonObject()
                .getAsJsonArray("candidates")
                ?.getOrNull(0)?.asJsonObject()
                ?.getAsJsonObject("content")
                ?.getAsJsonArray("parts")
                ?.getOrNull(0)?.asJsonObject()
                ?.get("text")?.asString() ?: ""

            if (generatedText.isBlank()) {
                return@withContext Result.failure(Exception("Empty response received from Gemini AI."))
            }

            // Parse output json
            val rawJson = cleanJsonResponse(generatedText)
            val parsedScriptResponse = jsonParser.decodeFromString<RawGeneratedScript>(rawJson)

            val audioDramaScript = AudioDramaScript(
                id = "custom_" + System.currentTimeMillis(),
                metadata = EpisodeMetadata(
                    episodeNumber = parsedScriptResponse.metadata?.episodeNumber ?: 1,
                    title = parsedScriptResponse.metadata?.title ?: "Custom Audio Drama Episode",
                    bookAuthorContext = parsedScriptResponse.metadata?.bookAuthorContext ?: "",
                    sceneSetting = parsedScriptResponse.metadata?.sceneSetting ?: "",
                    emotionalTone = parsedScriptResponse.metadata?.emotionalTone ?: "Emotional"
                ),
                characterVoices = parsedScriptResponse.characterVoices?.map { v ->
                    VoiceMapping(
                        characterId = v.characterId ?: "speaker",
                        name = v.name ?: "Character",
                        hindiName = v.hindiName ?: v.name ?: "पात्र",
                        voiceProfile = v.voiceProfile ?: "Standard Voice",
                        ageGroup = v.ageGroup ?: "Adult",
                        pitch = v.pitch ?: 1.0f,
                        speechRate = v.speechRate ?: 1.0f,
                        defaultEmotion = v.defaultEmotion ?: "Neutral"
                    )
                } ?: emptyList(),
                dialogueLines = parsedScriptResponse.dialogueLines?.mapIndexed { index, l ->
                    ScriptLine(
                        id = l.id ?: (index + 1),
                        speakerId = l.speakerId ?: "narrator",
                        speakerName = l.speakerName ?: "Speaker",
                        emotionCue = l.emotionCue ?: "Neutral",
                        breathCue = l.breathCue ?: "",
                        speedTag = l.speedTag ?: "1.0x",
                        text = l.text ?: "",
                        bgmCue = l.bgmCue,
                        sfxCue = l.sfxCue,
                        timestampMs = (index * 8000L)
                    )
                } ?: emptyList(),
                glossary = parsedScriptResponse.glossary?.map { g ->
                    GlossaryItem(
                        word = g.word ?: "",
                        meaning = g.meaning ?: "",
                        contextSentence = g.contextSentence ?: ""
                    )
                } ?: emptyList()
            )

            Result.success(audioDramaScript)
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    private fun cleanJsonResponse(raw: String): String {
        var clean = raw.trim()
        if (clean.startsWith("```json")) {
            clean = clean.removePrefix("```json")
        } else if (clean.startsWith("```")) {
            clean = clean.removePrefix("```")
        }
        if (clean.endsWith("```")) {
            clean = clean.removeSuffix("```")
        }
        return clean.trim()
    }

    private fun escapeJson(string: String): String {
        return Json.encodeToString(kotlinx.serialization.serializer(), string)
    }

    // Helper extensions for JSON parsing without heavy GSON
    private fun kotlinx.serialization.json.JsonElement.asJsonObject() = this as kotlinx.serialization.json.JsonObject
    private fun kotlinx.serialization.json.JsonObject.getAsJsonArray(key: String) = this[key] as? kotlinx.serialization.json.JsonArray
    private fun kotlinx.serialization.json.JsonObject.getAsJsonObject(key: String) = this[key] as? kotlinx.serialization.json.JsonObject
    private fun kotlinx.serialization.json.JsonElement.asString() = (this as? kotlinx.serialization.json.JsonPrimitive)?.content ?: ""
}

@Serializable
private data class RawGeneratedScript(
    val metadata: RawMetadata? = null,
    val characterVoices: List<RawVoice>? = null,
    val dialogueLines: List<RawLine>? = null,
    val glossary: List<RawGlossary>? = null
)

@Serializable
private data class RawMetadata(
    val episodeNumber: Int? = null,
    val title: String? = null,
    val bookAuthorContext: String? = null,
    val sceneSetting: String? = null,
    val emotionalTone: String? = null
)

@Serializable
private data class RawVoice(
    val characterId: String? = null,
    val name: String? = null,
    val hindiName: String? = null,
    val voiceProfile: String? = null,
    val ageGroup: String? = null,
    val pitch: Float? = null,
    val speechRate: Float? = null,
    val defaultEmotion: String? = null
)

@Serializable
private data class RawLine(
    val id: Int? = null,
    val speakerId: String? = null,
    val speakerName: String? = null,
    val emotionCue: String? = null,
    val breathCue: String? = null,
    val speedTag: String? = null,
    val text: String? = null,
    val bgmCue: String? = null,
    val sfxCue: String? = null,
    val timestampMs: Long? = null
)

@Serializable
private data class RawGlossary(
    val word: String? = null,
    val meaning: String? = null,
    val contextSentence: String? = null
)
